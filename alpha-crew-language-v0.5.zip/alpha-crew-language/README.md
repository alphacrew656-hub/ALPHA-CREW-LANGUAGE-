# Alpha Crew Language (ACL)

**A readable, English-inspired programming language — reference implementation v0.5.0.**

ACL is a working language built around readable instructions. Version 0.5.0 adds real networking: a built-in HTTP web server (`serve`), HTTP client (`http_get`, `http_post`, `download`), and security utilities (`hash_text`, `random_password`, `port_open`) — so ACL programs can be web APIs, CLI tools, and games. It is designed to grow toward a compiled systems language; it is not yet a replacement for C, Go, or Python.

## Run it

Requires Python 3.10 or newer. No third-party packages are required.

```sh
pip install .                 # installs the `acl` command
acl run examples/hello.acl
acl run examples/lists_and_maps.acl
acl run examples/notes.acl add "buy milk"
acl run examples/api_server.acl 8080      # real JSON API server
acl run examples/guess.acl                # game
acl check examples/fibonacci.acl
acl lint examples/notes.acl
acl format main.acl
acl new my_project
acl package my_project                    # distributable .aclpack bundle
acl test tests/
acl --repl
python -m unittest discover -s tests -v   # from the project directory
```

Run commands from this project directory. On systems where `python` means Python 2, use `python3` instead.

## Language preview

```text
make ages be {"ada": 36, "grace": 45}
set ages["linus"] to 28

make constant LIMIT as number be 100

each who in sorted(keys(ages)) do
    say who + " is " + text(ages[who])
end each

match length(ages)
when 0 then
    say "empty"
when it is greater than LIMIT then
    say "too many"
otherwise
    say "just right"
end match

to factorial with n
    if n is less than or equal to 1 then
        give back 1
    end if
    give back n * result of factorial with n - 1
end function

to greet with name, greeting be "Hello"
    say greeting + ", " + name
end function

try
    say number("oops")
catch as err
    say "Caught: " + err
end try
```

## Language features

- Variables: `make score be 10`, `change score to score + 1`
- Output: `say "Hello"` or `show score`; input: `ask "Name?" and save as name`
- Conditions: `if ... then`, `otherwise if ... then`, `otherwise`, `end if`
- Loops: `repeat 5 times`, `repeat with i from 1 to 10 step 2 do`, `while ... do`, `each item in list do`, plus `break loop` / `next loop`
- Lists, maps, and sets: literals, indexing, `set scores[0] to 99`, `put x into list`, `remove item at i from list`, `clear`, `union`, `intersection`, `difference`
- Typed variables and constants: `make score as number be 0`, `make constant MAX be 10`
- Pattern matching: `match value ... when ... then ... otherwise ... end match` (`it` refers to the matched value)
- Functions with real return values: `give back n * 2`, default parameters (`to greet with name, greeting be "Hi"`), recursion, and calls anywhere in expressions (`double(21)` or `result of double with 21`)
- Error handling: `try ... catch as err ... end try`
- Modules: `use "helpers.acl"` (loaded once, resolved relative to the current file)
- Standard library built-ins: files (`read_file`, `write_file`, `append_file`, `file_exists`, `delete_file`, `list_files`), data (`to_json`, `from_json`), system (`arguments`, `environment`), text (`format`, 15+ more), numbers, collections — see `docs/LANGUAGE.md`
- Networking and web: `serve port with handler` (real HTTP server; handlers get `{method, path, body}` and return text or `{status, body, content_type}`), `http_get`, `http_post`, `download` (certificate verification on by default)
- Security utilities (defensive use): `hash_text` (SHA-256), `random_password` (cryptographically secure), `port_open` (connectivity checks)
- Developer tools: `acl new` (project templates), `acl lint` (use-before-create, unreachable code), `acl format`, `acl check`, `acl run`
- Testing: `test "name" ... check that ... end test` blocks, `acl test` runner with pass/fail report and exit codes, fuzz-tested stability
- Safety and speed: cached expression parsing, memory guards on repetition and huge powers, execution-step limit, helpful line-numbered errors, multi-line REPL, unit tests

### Syntax rules

- Indentation is for readability; block endings are explicit.
- Variable and function names use letters, digits, and underscores, and cannot start with a digit.
- Use `#` or `//` to start a comment line (on its own line; inside expressions `//` is whole-number division).
- Function return values also land in `_last_result` after a `call` statement.

## Roadmap: from prototype to systems language

1. **Language specification:** stable grammar, types, scope, errors, and compatibility rules.
2. **Type checker:** explicit types plus inference, predictable conversions, and compile-time diagnostics.
3. **Native compiler:** compile ACL to LLVM IR or a documented C intermediate representation; optimize and emit native binaries.
4. **Systems features:** a carefully specified memory-safety model, safe low-level operations, FFI, and optional unsafe blocks.
5. **Standard library:** files, networking, concurrency, collections, cryptography through vetted libraries.
6. **Developer tools:** formatter, package manager, language server, debugger, and reproducible builds.
7. **Performance work:** benchmarks against equivalent C, Go, and Python programs; profiling; optimizer tests; published results.

“Stronger than C” needs a concrete definition (speed, safety, concurrency, portability, or developer productivity). This repository does not claim to beat C today. The native compiler, memory model, and benchmarks are the necessary next steps.

## Project layout

- `acl/` — interpreter and command-line interface
- `examples/` — runnable sample programs
- `tests/` — automated tests
- `docs/LANGUAGE.md` — language reference
- `upstream/jonesforth-master/` — original archive retained for provenance and study

## Foundation and licensing

The supplied JonesForth source states that `jonesforth.f` is public domain and includes a public-domain release statement. The upstream files are retained under `upstream/jonesforth-master/`; consult the original file headers for each file's provenance and licensing terms. ACL's Python implementation in `acl/` is a separate reference implementation and is released into the public domain under `UNLICENSE`.

## Status

Experimental / alpha. Syntax and behavior may change. Do not use for safety-critical systems or production services yet.
