import random, unittest
from acl.runtime import Interpreter, ACLError, set_script_args
from acl.tools import format_source

class V04Tests(unittest.TestCase):
    def execute(self, src, test_mode=False):
        out=[]; vm=Interpreter(output=out.append, input_fn=lambda p:'Ada')
        vm.test_mode=test_mode
        vm.run(src)
        return out, vm

    # short-circuit and/or
    def test_short_circuit_and(self):
        # RHS would fail if evaluated; short-circuit must protect it
        src='make items be [1]\nmake i be 5\nif i is less than length(items) and items[i] == 9 then\n say "yes"\notherwise\n say "no"\nend if'
        out,_=self.execute(src)
        self.assertEqual(out,['no'])
    def test_short_circuit_or(self):
        src='make x be 1\nif x is equal to 1 or missing_thing == 2 then\n say "safe"\nend if'
        out,_=self.execute(src)
        self.assertEqual(out,['safe'])

    # exit codes
    def test_exit(self):
        vm=Interpreter(output=lambda s:None)
        vm.run('say "before"\nexit with 7\nsay "after"')
        self.assertEqual(vm.exit_code,7)
    def test_exit_default(self):
        vm=Interpreter(output=lambda s:None)
        vm.run('exit')
        self.assertEqual(vm.exit_code,0)
    def test_exit_inside_function(self):
        vm=Interpreter(output=lambda s:None)
        vm.run('to quit_now\n exit with 3\nend function\ncall quit_now')
        self.assertEqual(vm.exit_code,3)

    # test framework statements
    def test_check_pass(self):
        out,vm=self.execute('test "math"\n check that 1 + 2 equals 3\nend test', test_mode=True)
        self.assertEqual(len(vm.test_results),1)
        name, ok, msg, line = vm.test_results[0]
        self.assertTrue(ok)
    def test_check_fail(self):
        vm=Interpreter(output=lambda s:None); vm.test_mode=True
        vm.run('test "broken"\n check that 1 + 2 equals 4\nend test')
        name, ok, msg, line = vm.test_results[0]
        self.assertFalse(ok); self.assertIn('check failed', msg)
    def test_check_truthy(self):
        vm=Interpreter(output=lambda s:None); vm.test_mode=True
        vm.run('test "t"\n check that 10 is greater than 5\nend test')
        self.assertTrue(vm.test_results[0][1])
    def test_check_outside_test_is_error(self):
        with self.assertRaises(ACLError):
            self.execute('check that 1 equals 1')
    def test_error_inside_test_fails_test(self):
        vm=Interpreter(output=lambda s:None); vm.test_mode=True
        vm.run('test "err"\n say missing_variable\nend test')
        name, ok, msg, line = vm.test_results[0]
        self.assertFalse(ok)
    def test_tests_noop_without_mode(self):
        out,vm=self.execute('test "t"\n say "inside"\nend test')
        self.assertEqual(out,[])

    # fuzz: malformed programs must never produce raw Python exceptions
    def test_fuzz_no_tracebacks(self):
        pieces=['say','make x be','if then','end','repeat','times','while do','each in',
                'match','when','otherwise','test "f"','check that','equals','exit with',
                'to f with','end function','call f with','give back','try','catch as e',
                'end try','use "nope.acl"','put into x','remove from x','set [ to 3',
                'add to','1 // 0','"unterminated','[1,2','{"a":','{1:','pause -1',
                'x[99]','nothing[0]','"a" * 999999999999','power(9, 99999999999)']
        rng=random.Random(42)
        for trial in range(400):
            n=rng.randint(1,8)
            src='\n'.join(' '.join(rng.choice(pieces) for _ in range(rng.randint(1,4))) for _ in range(n))
            vm=Interpreter(output=lambda s:None, input_fn=lambda p:'', max_steps=2000)
            try:
                vm.run(src)
            except ACLError:
                pass  # friendly errors are fine
            except Exception as e:
                self.fail(f"fuzz trial {trial} leaked {type(e).__name__}: {e}\n{src}")

    # formatter in place
    def test_format_write(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'f.acl'
            p.write_text('if true then\nsay "x"\nend if\n')
            from acl.tools import _format_file
            self.assertEqual(_format_file(str(p), write=True), 0)
            self.assertEqual(p.read_text(), 'if true then\n    say "x"\nend if\n')

if __name__=='__main__': unittest.main()
