import json as _json, tempfile, unittest
from pathlib import Path
from acl.runtime import Interpreter, ACLError, set_script_args
from acl.tools import lint_source, format_source

class FeatureTests(unittest.TestCase):
    def execute(self, src, base_dir=None, argv=None):
        out=[]; vm=Interpreter(output=out.append, input_fn=lambda prompt:'Ada')
        if argv is not None: set_script_args(argv)
        try: vm.run(src, base_dir=base_dir)
        finally: set_script_args(None)
        return out, vm

    # constants and typed variables
    def test_constant(self):
        with self.assertRaises(ACLError):
            self.execute('make constant MAX be 10\nchange MAX to 5')
    def test_constant_read(self):
        out,_=self.execute('make constant MAX be 10\nsay MAX')
        self.assertEqual(out,[10])
    def test_typed_variable(self):
        out,vm=self.execute('make score as number be 0\nadd 5 to score\nsay score')
        self.assertEqual(out,[5]); self.assertEqual(vm.var_types['score'],'number')
    def test_typed_variable_rejects(self):
        with self.assertRaises(ACLError):
            self.execute('make score as number be 0\nchange score to "oops"')
    def test_typed_equals_form(self):
        out,_=self.execute('make name as text = "Ada"\nsay name')
        self.assertEqual(out,['Ada'])

    # sets
    def test_set_literal_and_ops(self):
        out,_=self.execute('make a be {1, 2, 3}\nsay length(a)\nsay 2 in a\nsay length(union(a, {4}))\nsay length(intersection(a, {2, 3, 9}))')
        self.assertEqual(out,[3,True,4,2])

    # match
    def test_match_simple(self):
        src='make x be 2\nmatch x\nwhen 1 then\n say "one"\nwhen 2 then\n say "two"\notherwise\n say "many"\nend match'
        out,_=self.execute(src)
        self.assertEqual(out,['two'])
    def test_match_otherwise(self):
        src='match 99\nwhen 1 then\n say "one"\notherwise\n say "many"\nend match'
        out,_=self.execute(src)
        self.assertEqual(out,['many'])
    def test_match_with_it(self):
        src='match 42\nwhen it is greater than 40 then\n say "big"\notherwise\n say "small"\nend match'
        out,_=self.execute(src)
        self.assertEqual(out,['big'])

    # default parameters
    def test_default_params(self):
        src='to greet with name, greeting be "Hello"\n say greeting + ", " + name\nend function\ncall greet with "Ada"\ncall greet with "Ben", "Hey"'
        out,_=self.execute(src)
        self.assertEqual(out,['Hello, Ada','Hey, Ben'])
    def test_default_params_count_error(self):
        with self.assertRaises(ACLError):
            self.execute('to f with a, b be 1\n say a\nend function\ncall f')

    # format
    def test_format(self):
        out,_=self.execute('say format("Hi {0}, you are {1}!", "Ada", 30)')
        self.assertEqual(out,['Hi Ada, you are 30!'])

    # json
    def test_json_roundtrip(self):
        src='make data be {"a": 1, "b": [1, 2]}\nmake t be to_json(data)\nmake back be from_json(t)\nsay back["b"][1]'
        out,_=self.execute(src)
        self.assertEqual(out,[2])

    # files
    def test_files(self):
        with tempfile.TemporaryDirectory() as d:
            p=f"{d}/note.txt"
            out,vm=self.execute(f'call write_file with "{p}", "hello"\ncall append_file with "{p}", " world"\nsay read_file("{p}")\nsay file_exists("{p}")')
            self.assertEqual(out,['hello world',True])

    # command line arguments and environment
    def test_arguments(self):
        out,_=self.execute('make args be arguments()\nsay length(args)', argv=['x','y'])
        self.assertEqual(out,[2])

    # safety guards
    def test_repetition_guard(self):
        with self.assertRaises(ACLError):
            self.execute('say "a" * 100000000')
    def test_power_guard(self):
        with self.assertRaises(ACLError):
            self.execute('say power(9, 999999999999)')

    # speed: cached parsing produces identical results
    def test_cached_parse_consistent(self):
        out,_=self.execute('make total be 0\nrepeat with i from 1 to 100 do\n add i to total\nend repeat\nsay total')
        self.assertEqual(out,[5050])

    # lint
    def test_lint_use_before_create(self):
        warnings=lint_source('change x to 5')
        self.assertTrue(any('W001' in w for w in warnings))
    def test_lint_clean(self):
        self.assertEqual(lint_source('make x be 1\nsay x'), [])
    def test_lint_unreachable(self):
        warnings=lint_source('make x be 1\nstop\nsay x')
        self.assertTrue(any('W002' in w for w in warnings))

    # formatter
    def test_format_source_indents(self):
        got=format_source('if true then\nsay "x"\nend if')
        self.assertEqual(got, 'if true then\n    say "x"\nend if\n')

if __name__=='__main__': unittest.main()
