import os, socket, subprocess, sys, tempfile, time, unittest, urllib.request
from pathlib import Path
from acl.runtime import Interpreter, ACLError

ROOT = Path(__file__).resolve().parent.parent
TEST_PORT = 8137

class V05Tests(unittest.TestCase):
    def execute(self, src):
        out=[]; vm=Interpreter(output=out.append, input_fn=lambda p:'Ada')
        vm.run(src)
        return out, vm

    def test_hash_text(self):
        out,_=self.execute('say hash_text("abc")')
        self.assertEqual(out, ['ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'])
    def test_random_password(self):
        out,_=self.execute('make p be random_password(20)\nsay length(p)\nmake q be random_password(20)\nsay p == q')
        self.assertEqual(out,[20,False])
    def test_port_open_false(self):
        out,_=self.execute(f'say port_open("127.0.0.1", {TEST_PORT + 1}, 0.2)')
        self.assertEqual(out,[False])

    def test_http_server_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            srv=Path(d)/'srv.acl'
            srv.write_text(
                'to handle with req\n'
                '    if req["path"] is equal to "/json" then\n'
                '        give back {"status": 200, "body": to_json({"ok": true}), "content_type": "application/json"}\n'
                '    end if\n'
                '    if req["method"] is equal to "POST" and req["path"] is equal to "/sum" then\n'
                '        give back to_json({"sum": sum(from_json(req["body"])["numbers"])})\n'
                '    end if\n'
                '    give back "hello " + req["path"]\n'
                'end function\n'
                f'serve {TEST_PORT} with handle\n', encoding='utf-8')
            env=dict(os.environ, PYTHONPATH=str(ROOT))
            p=subprocess.Popen([sys.executable,'-m','acl','run',str(srv)],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=env)
            try:
                up=False
                for _ in range(50):
                    if self._port_open(): up=True; break
                    time.sleep(0.1)
                self.assertTrue(up, 'server did not start')
                with urllib.request.urlopen(f'http://127.0.0.1:{TEST_PORT}/world', timeout=5) as r:
                    self.assertEqual(r.read().decode(), 'hello /world')
                req=urllib.request.Request(f'http://127.0.0.1:{TEST_PORT}/sum', data=b'{"numbers":[1,2,3]}', method='POST')
                with urllib.request.urlopen(req, timeout=5) as r:
                    self.assertIn('6', r.read().decode())
                with urllib.request.urlopen(f'http://127.0.0.1:{TEST_PORT}/json', timeout=5) as r:
                    self.assertEqual(r.headers['Content-Type'], 'application/json')
                    self.assertEqual(r.read().decode(), '{"ok": true}')
                with urllib.request.urlopen(f'http://127.0.0.1:{TEST_PORT}/missing', timeout=5) as r:
                    self.assertEqual(r.read().decode(), 'hello /missing')
            finally:
                p.kill(); p.wait()
    @staticmethod
    def _port_open():
        try:
            with socket.create_connection(('127.0.0.1', TEST_PORT), timeout=0.3):
                return True
        except OSError:
            return False

    def test_package_project(self):
        from acl.tools import package_project
        with tempfile.TemporaryDirectory() as d:
            proj=Path(d)/'proj'
            (proj).mkdir()
            (proj/'main.acl').write_text('say "hi"\n', encoding='utf-8')
            self.assertEqual(package_project(str(proj)), 0)
            self.assertTrue((proj.parent/'proj.aclpack').exists())

if __name__=='__main__': unittest.main()
