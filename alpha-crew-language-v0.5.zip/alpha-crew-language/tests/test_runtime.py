import tempfile, unittest
from pathlib import Path
from acl.runtime import Interpreter, ACLError, Parser

class RuntimeTests(unittest.TestCase):
    def execute(self, src):
        out=[]; vm=Interpreter(output=out.append, input_fn=lambda prompt:'Ada')
        vm.run(src); return out, vm
    def test_say_and_variables(self):
        out,vm=self.execute('make x be 4\nadd 3 to x\nsay x')
        self.assertEqual(out,[7]); self.assertEqual(vm.env['x'],7)
    def test_condition(self):
        out,_=self.execute('make x be 8\nif x is greater than 5 then\n say "yes"\notherwise\n say "no"\nend if')
        self.assertEqual(out,['yes'])
    def test_otherwise_if_chain(self):
        src=('make n be 3\n'
             'if n is equal to 1 then\n say "one"\n'
             'otherwise if n is equal to 2 then\n say "two"\n'
             'otherwise if n is equal to 3 then\n say "three"\n'
             'otherwise\n say "many"\nend if')
        out,_=self.execute(src)
        self.assertEqual(out,['three'])
    def test_repeat(self):
        out,_=self.execute('make x be 0\nrepeat 3 times\n add 1 to x\nend repeat\nsay x')
        self.assertEqual(out,[3])
    def test_for_loop(self):
        out,_=self.execute('make total be 0\nrepeat with i from 1 to 4 do\n add i to total\nend repeat\nsay total')
        self.assertEqual(out,[10])
    def test_for_loop_step(self):
        out,_=self.execute('repeat with i from 10 to 1 step -3 do\n say i\nend repeat')
        self.assertEqual(out,[10,7,4,1])
    def test_each_loop(self):
        out,_=self.execute('each fruit in ["apple", "pear"] do\n say fruit\nend each')
        self.assertEqual(out,['apple','pear'])
    def test_each_over_map_keys(self):
        out,_=self.execute('make ages be {"ada": 36, "ben": 24}\neach who in ages do\n say who\nend each')
        self.assertEqual(out,['ada','ben'])
    def test_break_and_next(self):
        src=('make seen be 0\nrepeat with i from 1 to 10 do\n if i is equal to 3 then\n  next loop\nend\n if i is greater than 5 then\n  break loop\nend\n'
             'change seen to i\nend repeat\nsay seen')
        out,_=self.execute(src)
        self.assertEqual(out,[5])
    def test_function(self):
        out,_=self.execute('to greet with who\n say "Hi " + who\nend function\ncall greet with "Ada"')
        self.assertEqual(out,['Hi Ada'])
    def test_result_of_in_expression(self):
        out,_=self.execute('to double with n\n give back n * 2\nend function\nmake x be result of double with 21\nsay x')
        self.assertEqual(out,[42])
    def test_recursion(self):
        src=('to factorial with n\n if n is less than or equal to 1 then\n  give back 1\nend\n give back n * result of factorial with n - 1\nend function\n'
             'say result of factorial with 6')
        out,_=self.execute(src)
        self.assertEqual(out,[720])
    def test_lists(self):
        src=('make scores be [10, 30, 20]\nput 50 into scores\nset scores[2] to 25\nremove item at 0 from scores\nsay length(scores)\nsay max(scores)\nsay sum(scores)')
        out,_=self.execute(src)
        self.assertEqual(out,[3,50,105])
    def test_maps(self):
        src=('make ages be {"ada": 36}\nset ages["ben"] to 24\nsay ages["ben"]\nsay has_key(ages, "ada")\nsay join(keys(ages), ", ")')
        out,_=self.execute(src)
        self.assertEqual(out,[24,True,'ada, ben'])
    def test_string_builtins(self):
        src=('make name be "  Ada Lovelace  "\nsay trim(name)\nsay upper("abc")\nsay split("a,b,c", ",")\nsay replace("hello", "l", "L")\nsay starts_with("acl", "a")')
        out,_=self.execute(src)
        self.assertEqual(out,['Ada Lovelace','ABC',['a','b','c'],'heLLo',True])
    def test_membership(self):
        out,_=self.execute('say 2 in [1, 2, 3]\nsay "x" not in ["y"]')
        self.assertEqual(out,[True,True])
    def test_math_builtins(self):
        out,_=self.execute('say abs(-5)\nsay floor(2.7)\nsay ceiling(2.1)\nsay sqrt(16)\nsay power(2, 10)\nsay average([2, 4, 6])')
        self.assertEqual(out,[5,2,3,4.0,1024,4.0])
    def test_try_catch(self):
        src=('try\n say missing_variable\ncatch as err\n say "caught"\nsay err is not nothing\nend try')
        out,_=self.execute(src)
        self.assertEqual(out,['caught',True])
    def test_try_catch_scoped(self):
        src=('try\n make good be 1 // 0\ncatch as err\n make good be 7\nend try\nsay good')
        out,_=self.execute(src)
        self.assertEqual(out,[7])
    def test_use_module(self):
        with tempfile.TemporaryDirectory() as d:
            lib=Path(d)/'math.acl'
            lib.write_text('to triple with n\n give back n * 3\nend function\n')
            out=[]; vm=Interpreter(output=out.append)
            vm.run('use "math.acl"\nsay result of triple with 5', base_dir=d)
            self.assertEqual(out,[15])
    def test_use_module_cached(self):
        with tempfile.TemporaryDirectory() as d:
            lib=Path(d)/'counter.acl'
            lib.write_text('make loaded be 1\n')
            out=[]; vm=Interpreter(output=out.append)
            vm.run('use "counter.acl"\nuse "counter.acl"\nsay loaded', base_dir=d)
            self.assertEqual(out,[1])
    def test_break_outside_loop_is_error(self):
        with self.assertRaises(ACLError): self.execute('break loop')
    def test_input(self):
        out,vm=self.execute('ask "Name?" and save as name\nsay name')
        self.assertEqual(out,['Ada'])
    def test_bad_name_is_helpful(self):
        with self.assertRaises(ACLError): self.execute('say missing_variable')
    def test_check_parse(self):
        Parser('if true then\n say "ok"\nend if').parse()
        Parser('try\n say "x"\ncatch as err\n say err\nend try').parse()
        Parser('each x in [1] do\n say x\nend each').parse()

if __name__=='__main__': unittest.main()
