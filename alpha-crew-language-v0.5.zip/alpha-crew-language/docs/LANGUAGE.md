# Alpha Crew Language — language reference (v0.5.0)

## Statements

| Statement | Meaning |
|---|---|
| `say expression` / `show expression` | Evaluate and print a value |
| `make name be expression` | Create or assign a variable |
| `change name to expression` | Assign a variable |
| `set name[index] to expression` | Assign to a list position or map key |
| `add expression to name` | Add to an existing numeric variable |
| `put value into list_name` | Append a value to a list |
| `remove item at index from list_name` | Delete a list element by position |
| `clear list_name` | Empty a list or map |
| `ask "Prompt" and save as name` | Read a line of text into a variable |
| `if expression then ... otherwise if ... then ... otherwise ... end if` | Conditional block; `otherwise if` chains and `otherwise` are optional |
| `repeat expression times ... end repeat` | Repeat a fixed whole-number count |
| `repeat with i from 1 to 10 [step 2] do ... end repeat` | Counting loop, inclusive, optional step |
| `while expression do ... end while` | Repeat while condition is true |
| `each item in list_or_map_or_text ... end each` | Iterate over a list (values), a map (keys), or text (characters) |
| `break loop` / `next loop` | Leave the current loop / skip to the next round |
| `to name with arg, other ... end function` | Define a function |
| `call name with expression, other` | Call a function; result is also stored in `_last_result` |
| `result of name with expression` | Call a function inside any expression |
| `give back [expression]` | Return a value (or nothing) from a function |
| `try ... catch as err ... end try` | Run code; if an ACL error happens, `err` holds the message and the catch block runs |
| `use "file.acl"` | Load a module file once (relative to the current file) |
| `pause expression` | Wait that many seconds (max 60) |
| `exit` / `exit with code` | End the program with an exit code (default 0) |
| `serve port with handler_function` | Run a real HTTP server on 127.0.0.1; each request calls the function with a map `{method, path, body}`; return text or a map `{status, body, content_type}` |
| `test "description" ... check that ... end test` | A named test block; runs only under `acl test`, silent no-op otherwise |
| `check that expression` / `check that expression equals value` | Assertion inside a test |
| `stop` / `finish` | Stop the current function or program |

## Expressions

Numbers, quoted strings, `true`, `false`, `nothing`, variable names, lists (`[1, 2, 3]`), maps (`{"key": value}` or `{}`), indexing (`items[0]`, `ages["ada"]`), parentheses, arithmetic (`+ - * / // % **`), comparisons (`== != < <= > >=`), membership (`x in list`, `x not in list`), and boolean operators (`and`, `or`, `not`) are supported.

Sets use braces without colons: `{1, 2, 3}`. User-defined functions can be called directly in expressions: `double(21)`.

Natural comparison forms include `is equal to`, `is not equal to`, `is greater than`, `is less than`, `is greater than or equal to` (also `is at least`), `is less than or equal to` (also `is at most`), `is nothing`, and `is not nothing`. The boolean operators `and` and `or` short-circuit: the right side is not evaluated when the left side already decides the result.

### Built-in functions

- **Text:** `upper`, `lower`, `trim`, `split(text[, sep])`, `join(list, sep)`, `replace(text, old, new)`, `starts_with`, `ends_with`, `contains`, `find`, `character(text, i)`, `slice(value, start[, end])`, `format(text, ...)`
- **Numbers:** `abs`, `floor`, `ceiling`, `sqrt`, `power(a, b)`, `round(value[, digits])`, `whole`, `number`, `random(low, high)`
- **Lists:** `length`, `sorted`, `reversed`, `min`, `max`, `sum`, `average`
- **Maps:** `keys`, `values`, `has_key`
- **Sets:** `to_set`, `union`, `intersection`, `difference`
- **Files:** `read_file(path)`, `write_file(path, text)`, `append_file(path, text)`, `file_exists(path)`, `delete_file(path)`, `list_files(dir)`
- **Data and system:** `to_json(value)`, `from_json(text)`, `arguments()` (command-line arguments), `environment(name)`, `text(value)`, `kind(value)`, `now()` (seconds since 1970)
- **Network:** `http_get(url)`, `http_post(url, body[, content_type])`, `download(url, path)` — certificate verification on by default
- **Security:** `hash_text(text)` (SHA-256), `random_password(length[, symbols])`, `port_open(host, port[, timeout])`

## Example: functions, maps, and error handling

```text
to factorial with n
    if n is less than or equal to 1 then
        give back 1
    end if
    give back n * result of factorial with n - 1
end function

make ages be {"ada": 36}
set ages["ben"] to 24

try
    say number("not a number")
catch as err
    say "Caught: " + err
end try

say result of factorial with 6
```

## Syntax rules

- Indentation is for readability; block endings are explicit (`end if`, `end repeat`, `end while`, `end each`, `end try`, `end function`).
- Variable and function names use letters, digits, and underscores, and cannot start with a digit.
- Use `#` or `//` to start a comment line. Note: inside expressions `//` means whole-number division, so keep comments on their own line.
- In a `result of` expression, the arguments extend to the end of the expression; wrap the call in parentheses to keep computing afterwards: `(result of f with 2) * 3`.

## Current limitations

This is still an interpreted reference implementation, not a native compiler. It has no static types, no optimizer, no concurrency, and no native FFI yet. Booleans evaluate both sides (`and`/`or` are not short-circuit). These are the next steps toward a systems-grade 1.0.
