"""Project generator, formatter, and linter for ACL."""
from __future__ import annotations
import ast, re
import zipfile
from pathlib import Path
from .runtime import Parser, ACLError, Expr

_NEW_MAIN = '''# {name} — an Alpha Crew Language project

make constant APP_NAME be "{name}"

to welcome with who
    give back format("Welcome to {{0}}, {{1}}!", APP_NAME, who)
end function

say welcome("world")

make scores as list be [10, 20, 30]
put 40 into scores

each s in scores do
    say "Score: " + text(s)
end each

say "Average: " + text(average(scores))
'''

_NEW_README = '''# {name}

An Alpha Crew Language project.

## Run

```sh
python -m acl run main.acl
```

## Check and lint

```sh
python -m acl check main.acl
python -m acl lint main.acl
```
'''

def new_project(name):
    root=Path(name)
    if root.exists():
        print(f"ACL: '{name}' already exists"); return 1
    root.mkdir(parents=True)
    (root/'main.acl').write_text(_NEW_MAIN.format(name=name), encoding='utf-8')
    (root/'README.md').write_text(_NEW_README.format(name=name), encoding='utf-8')
    print(f"Created project '{name}'")
    print(f"  {name}/main.acl")
    print(f"  {name}/README.md")
    print(f"Run it: python -m acl run {name}/main.acl")
    return 0

def _is_opener(low):
    return low=='try' or low.startswith(('if ','repeat','while ','to ','each ','match '))

def _is_clause(low):
    return low in ('otherwise','catch') or low.startswith(('otherwise ','when ','catch '))

def format_source(source):
    out=[]; depth=0
    for raw in source.splitlines():
        s=raw.strip()
        if not s:
            out.append(''); continue
        low=s.lower()
        if low.startswith('end '): depth=max(0, depth-1)
        elif _is_clause(low):
            out.append('    '*max(0, depth-1)+s)
            continue
        out.append('    '*depth+s)
        if _is_opener(low): depth+=1
    return '\n'.join(out)+'\n'

def format_file(path):
    return _format_file(path, write=False)

def _format_file(path, write=False):
    p=Path(path)
    try: source=p.read_text(encoding='utf-8')
    except OSError as e:
        print(f"ACL: cannot read {p}: {e}"); return 2
    if write:
        p.write_text(format_source(source), encoding='utf-8')
        print(f'{p}: formatted'); return 0
    print(format_source(source), end='')
    return 0

def _expression_names(text):
    """Best-effort: return variable names referenced by an ACL expression."""
    try:
        text=Expr.normalize(text)
        text=Expr({}, 0)._transform_calls(text)
        tree=ast.parse(text, mode='eval')
    except Exception:
        return set()
    names={n.id for n in ast.walk(tree) if isinstance(n, ast.Name)}
    return names - {'it'} - Expr._BUILTIN_NAMES

def lint_source(source):
    warnings=[]
    try: program=Parser(source).parse()
    except ACLError as e:
        return [f"E001 {e}"]
    stop_kinds=('return','stop','break','continue')
    def walk(stmts, defined):
        unreachable=False
        for st in stmts:
            if unreachable:
                warnings.append(f"W002 line {st.line}: unreachable code (stop/finish/give back/break came before it)")
                unreachable=False  # one warning per block is enough
            k=st.kind
            if k in ('make','make_typed','const'):
                defined.add(st.args[0])
            elif k=='set':
                if st.args[0] not in defined:
                    warnings.append(f"W001 line {st.line}: '{st.args[0]}' is changed before it is created with make")
                defined.add(st.args[0])
            elif k=='set_index':
                name=st.args[0].split('[',1)[0]
                if name not in defined:
                    warnings.append(f"W001 line {st.line}: '{name}' is changed before it is created with make")
            elif k in ('append','remove_at','clear'):
                if st.args[-1] not in defined:
                    warnings.append(f"W001 line {st.line}: '{st.args[-1]}' is used before it is created with make")
            elif k=='ask':
                defined.add(st.args[1])
            exprs=[]
            if k=='say': exprs=[st.args[0]]
            elif k in ('make','set','const'): exprs=[st.args[-1]]
            elif k=='make_typed': exprs=[st.args[2]]
            elif k=='if': exprs=[st.args[0]]
            elif k=='while': exprs=[st.args[0]]
            elif k=='repeat': exprs=[st.args[0]]
            elif k=='each': exprs=[st.args[1]]
            elif k=='match': exprs=[st.args[0]]+[c[0] for c in st.args[1]]
            elif k=='return': exprs=[st.args[0]] if st.args[0] else []
            elif k=='call': exprs=[st.args[1]] if st.args[1].strip() else []
            elif k in ('append','remove_at','pause'): exprs=[st.args[0]]
            for e in exprs:
                for n in _expression_names(e):
                    if n not in defined:
                        warnings.append(f"W003 line {st.line}: '{n}' is used here but has not been created yet")
            local=defined.copy()
            if k=='function':
                defined.add(st.args[0])
                local.add(st.args[0])
                walk(st.body, local | {p for p, _ in st.args[1]})
            elif k in ('for','each'):
                walk(st.body, local | {st.args[0]})
            elif k=='match':
                for _,wbody in st.args[1]: walk(wbody, local.copy())
                if st.other: walk(st.other, local.copy())
            elif k=='try':
                walk(st.body, local.copy())
                if st.other: walk(st.other, local | {st.args[0]})
            elif k=='if':
                walk(st.body, local.copy())
                if st.other: walk(st.other, local.copy())
            elif k in ('repeat','while'):
                walk(st.body, local.copy())
            if k in stop_kinds: unreachable=True
    walk(program, set())
    return warnings

def lint_file(path):
    p=Path(path)
    try: source=p.read_text(encoding='utf-8')
    except OSError as e:
        print(f"ACL: cannot read {p}: {e}"); return 2
    warnings=lint_source(source)
    if not warnings:
        print(f"{p}: no problems found"); return 0
    for w in warnings: print(w)
    print(f"{p}: {len(warnings)} warning(s)")
    return 0

def package_project(path):
    """Bundle a project directory into a distributable .aclpack zip."""
    p=Path(path)
    if not p.is_dir():
        print(f"ACL: '{path}' is not a project directory"); return 2
    out=Path(str(p)+'.aclpack')
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in sorted(p.rglob('*')):
            if f.is_file() and '__pycache__' not in f.parts and '.git' not in f.parts:
                z.write(f, f.relative_to(p.parent))
    print(f"Packaged {p} -> {out}")
    return 0
