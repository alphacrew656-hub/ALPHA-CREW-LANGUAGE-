"""Alpha Crew Language reference interpreter (ACL), version 0.5.0."""
from __future__ import annotations
import ast, hashlib, http.server, json, math, os, random as _random, re, secrets, socket, sys, time, urllib.parse, urllib.request
from dataclasses import dataclass
from pathlib import Path

VERSION = "0.5.0"

_SCRIPT_ARGS = None

def set_script_args(args):
    """Set what arguments() returns inside ACL programs."""
    global _SCRIPT_ARGS
    _SCRIPT_ARGS = None if args is None else list(args)

_TYPE_NAMES = {'number','text','truefalse','list','map','set'}

class ACLError(Exception):
    def __init__(self, message, line=None):
        self.line = line
        super().__init__((f"Line {line}: " if line else "") + message)

class ACLBreak(Exception): pass
class ACLContinue(Exception): pass
class ACLReturn(Exception):
    def __init__(self, value=None): self.value = value

class ACLExit(Exception):
    def __init__(self, code=0): self.code = code

_MISSING = object()

@dataclass
class Stmt:
    kind: str
    args: tuple
    line: int
    body: list
    other: list | None = None

class Expr:
    """Small safe expression evaluator; never uses Python eval/exec."""
    OPS = {ast.Add: lambda a,b:a+b, ast.Sub:lambda a,b:a-b, ast.Mult:lambda a,b:a*b,
           ast.Div:lambda a,b:a/b, ast.FloorDiv:lambda a,b:a//b, ast.Mod:lambda a,b:a%b,
           ast.Pow:lambda a,b:a**b, ast.Eq:lambda a,b:a==b, ast.NotEq:lambda a,b:a!=b,
           ast.Lt:lambda a,b:a<b, ast.LtE:lambda a,b:a<=b, ast.Gt:lambda a,b:a>b,
           ast.GtE:lambda a,b:a>=b, ast.In:lambda a,b:a in b, ast.NotIn:lambda a,b:a not in b}
    _AST_CACHE = {}
    _MAX_MEMORY_ITEMS = 10_000_000
    _MAX_POWER = 100_000
    _BUILTIN_NAMES = frozenset({
        'length','text','format','upper','lower','trim','split','join','replace','contains',
        'starts_with','ends_with','find','slice','character','number','whole','round','abs',
        'floor','ceiling','sqrt','power','random','now','sorted','reversed','min','max','sum',
        'average','keys','values','has_key','to_set','union','intersection','difference',
        'read_file','write_file','append_file','file_exists','delete_file','list_files',
        'to_json','from_json','arguments','environment','kind',
        'http_get','http_post','download','hash_text','random_password','port_open'})

    def __init__(self, env, line, interp=None):
        self.env, self.line, self.interp = env, line, interp

    @staticmethod
    def normalize(text):
        text = re.sub(r'\bis not equal to\b|\bis different from\b', '!=', text, flags=re.I)
        text = re.sub(r'\bis equal to\b|\bis the same as\b', '==', text, flags=re.I)
        text = re.sub(r'\bis greater than or equal to\b|\bis at least\b', '>=', text, flags=re.I)
        text = re.sub(r'\bis less than or equal to\b|\bis at most\b', '<=', text, flags=re.I)
        text = re.sub(r'\bis greater than\b', '>', text, flags=re.I)
        text = re.sub(r'\bis less than\b', '<', text, flags=re.I)
        text = re.sub(r'\bis not nothing\b', '!= nothing', text, flags=re.I)
        text = re.sub(r'\bis nothing\b', '== nothing', text, flags=re.I)
        return text

    def evaluate(self, text):
        text = self.normalize(text.strip())
        # Function calls inside expressions: result of name with a, b
        text = self._transform_calls(text)
        try: node = self._cached_parse(text)
        except SyntaxError as e: raise ACLError(f"I couldn't understand this expression: {text}", self.line) from e
        return self._node(node)
    @classmethod
    def _cached_parse(cls, text):
        node = cls._AST_CACHE.get(text)
        if node is None:
            node = ast.parse(text, mode='eval').body
            if len(cls._AST_CACHE) < 100_000: cls._AST_CACHE[text] = node
        return node
    def _transform_calls(self, text):
        """Rewrite 'result of name with args' into a placeholder call that the
        expression parser understands. The innermost/last call is rewritten
        first so nested calls work. Parentheses and strings inside the
        argument area are respected."""
        while True:
            starts=[m.start() for m in re.finditer(r'\bresult of\b', text, re.I)]
            if not starts: return text
            start=starts[-1]
            m=re.match(r'result of\s+([A-Za-z_]\w*)(?:\s+with\s+)?', text[start:], re.I)
            if not m: raise ACLError('Use: result of function_name with argument, another', self.line)
            fname=m.group(1); pos=start+m.end(); end=len(text); depth=0; quote=None; esc=False
            for j in range(pos, len(text)):
                c=text[j]
                if quote:
                    if esc: esc=False
                    elif c=='\\': esc=True
                    elif c==quote: quote=None
                elif c in ('"',"'"): quote=c
                elif c=='(': depth+=1
                elif c==')':
                    if depth==0: end=j; break
                    depth-=1
                elif c==',' and depth==0: end=j; break
            args=text[pos:end].strip()
            call=f"__acl_call_{fname}({args})"
            text=text[:start]+call+text[end:]
    def _node(self, n):
        if isinstance(n, ast.Constant) and isinstance(n.value, (str,int,float,bool,type(None))): return n.value
        if isinstance(n, ast.Name):
            if n.id in ('true','True'): return True
            if n.id in ('false','False'): return False
            if n.id in ('nothing','None'): return None
            if n.id not in self.env: raise ACLError(f"'{n.id}' has not been created yet", self.line)
            return self.env[n.id]
        if isinstance(n, ast.List): return [self._node(x) for x in n.elts]
        if isinstance(n, ast.Tuple): return tuple(self._node(x) for x in n.elts)
        if isinstance(n, ast.Set): return {self._node(x) for x in n.elts}
        if isinstance(n, ast.Dict):
            if any(k is None for k in n.keys): raise ACLError("Map literal shortcuts like {:**} are not supported", self.line)
            return {self._node(k): self._node(v) for k, v in zip(n.keys, n.values)}
        if isinstance(n, ast.BinOp) and type(n.op) in self.OPS:
            left=self._node(n.left); right=self._node(n.right)
            self._guard(n.op, left, right)
            try: return self.OPS[type(n.op)](left, right)
            except ACLError: raise
            except Exception as e: raise ACLError(f"Math operation failed: {e}", self.line) from e
        if isinstance(n, ast.UnaryOp):
            v=self._node(n.operand)
            if isinstance(n.op, ast.USub): return -v
            if isinstance(n.op, ast.UAdd): return +v
            if isinstance(n.op, ast.Not): return not v
        if isinstance(n, ast.BoolOp):
            # Short-circuit: stop evaluating as soon as the answer is known.
            if isinstance(n.op, ast.And):
                for v in n.values:
                    if not self._node(v): return False
                return True
            for v in n.values:
                if self._node(v): return True
            return False
        if isinstance(n, ast.Compare):
            left=self._node(n.left)
            for op, right_node in zip(n.ops,n.comparators):
                right=self._node(right_node)
                fn=self.OPS.get(type(op))
                if not fn or not fn(left,right): return False
                left=right
            return True
        if isinstance(n, ast.Subscript):
            try: return self._node(n.value)[self._node(n.slice)]
            except (IndexError, KeyError, TypeError) as e:
                raise ACLError("That position does not exist in the list or map", self.line) from e
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name):
            name=n.func.id; args=[self._node(a) for a in n.args]
            if name.startswith('__acl_call_'):
                if self.interp is None: raise ACLError("Functions cannot be called in this context", self.line)
                return self.interp.call_function(name[len('__acl_call_'):], args, self.line)
            if name in self._BUILTIN_NAMES: return self._builtin(name, args)
            if self.interp is not None and name in self.interp.functions:
                return self.interp.call_function(name, args, self.line)
            raise ACLError(f"Unknown function '{name}' — did you mean 'result of {name} with ...'?", self.line)
        raise ACLError(f"That expression uses a feature not supported by ACL yet ({type(n).__name__})", self.line)
    def _guard(self, op, left, right):
        # Refuse operations that would allocate absurd amounts of memory or time.
        if isinstance(op, ast.Mult):
            for a,b in ((left,right),(right,left)):
                if isinstance(a,(str,list,tuple)) and isinstance(b,int) and not isinstance(b,bool):
                    if len(a)*abs(b) > self._MAX_MEMORY_ITEMS:
                        raise ACLError("That repetition is too large (over 10 million items)", self.line)
        if isinstance(op, ast.Pow) and isinstance(left,(int,float)) and isinstance(right,(int,float)) \
                and not (isinstance(left,bool) or isinstance(right,bool)):
            if abs(right) > self._MAX_POWER:
                raise ACLError(f"That power is too large (exponent {right})", self.line)
    def _builtin(self, name, a):
        def need(count):
            if len(a) not in (count if isinstance(count, tuple) else (count,)):
                raise ACLError(f"{name}() expects {count} argument(s), got {len(a)}", self.line)
        # --- text ---
        if name == 'length' and len(a)==1: return len(a[0])
        if name == 'text' and len(a)==1: return str(a[0])
        if name == 'format' and len(a)>=1:
            def sub(m):
                i=int(m.group(1))
                if not (0 <= i < len(a)-1): raise ACLError(f"format() has no argument {i}", self.line)
                return str(a[i+1])
            return re.sub(r'\{(\d+)\}', sub, str(a[0]))
        if name == 'upper' and len(a)==1: return str(a[0]).upper()
        if name == 'lower' and len(a)==1: return str(a[0]).lower()
        if name == 'trim' and len(a)==1: return str(a[0]).strip()
        if name == 'split' and len(a) in (1,2): return str(a[0]).split(a[1] if len(a)==2 else None)
        if name == 'join' and len(a)==2: return str(a[1]).join(str(x) for x in a[0])
        if name == 'replace' and len(a)==3: return str(a[0]).replace(str(a[1]), str(a[2]))
        if name == 'contains' and len(a)==2: return a[1] in a[0]
        if name == 'starts_with' and len(a)==2: return str(a[0]).startswith(str(a[1]))
        if name == 'ends_with' and len(a)==2: return str(a[0]).endswith(str(a[1]))
        if name == 'find' and len(a)==2:
            try: return list(a[0]).index(a[1]) if not isinstance(a[0], str) else a[0].find(a[1])
            except ValueError: return -1
        if name == 'slice' and len(a) in (2,3): return a[0][a[1]:(a[2] if len(a)==3 else None)]
        if name == 'character' and len(a)==2: return str(a[0])[int(a[1])]
        # --- numbers ---
        if name == 'number' and len(a)==1:
            try: return float(a[0]) if '.' in str(a[0]) else int(a[0])
            except (TypeError, ValueError): raise ACLError(f"number() cannot convert {a[0]!r}", self.line)
        if name == 'whole' and len(a)==1:
            try: return int(a[0])
            except (TypeError, ValueError): raise ACLError(f"whole() cannot convert {a[0]!r}", self.line)
        if name == 'round' and len(a) in (1,2): return round(*a)
        if name == 'abs' and len(a)==1: return abs(a[0])
        if name == 'floor' and len(a)==1: return math.floor(a[0])
        if name == 'ceiling' and len(a)==1: return math.ceil(a[0])
        if name == 'sqrt' and len(a)==1:
            if a[0] < 0: raise ACLError("sqrt() of a negative number", self.line)
            return math.sqrt(a[0])
        if name == 'power' and len(a)==2:
            if isinstance(a[0],(int,float)) and isinstance(a[1],(int,float)) and abs(a[1]) > Expr._MAX_POWER:
                raise ACLError(f"That power is too large (exponent {a[1]})", self.line)
            return a[0] ** a[1]
        if name == 'random' and len(a)==2:
            lo, hi = int(a[0]), int(a[1])
            if lo > hi: lo, hi = hi, lo
            return _random.randint(lo, hi)
        if name == 'now' and len(a)==0: return time.time()
        # --- lists ---
        if name == 'sorted' and len(a)==1: return sorted(a[0])
        if name == 'reversed' and len(a)==1: return list(reversed(a[0]))
        if name == 'min' and len(a)>=1:
            try: return min(a[0]) if len(a)==1 else min(a)
            except (TypeError, ValueError) as e: raise ACLError(f"min() failed: {e}", self.line)
        if name == 'max' and len(a)>=1:
            try: return max(a[0]) if len(a)==1 else max(a)
            except (TypeError, ValueError) as e: raise ACLError(f"max() failed: {e}", self.line)
        if name == 'sum' and len(a)==1: return sum(a[0])
        if name == 'average' and len(a)==1:
            if len(a[0])==0: raise ACLError("average() of an empty list", self.line)
            return sum(a[0])/len(a[0])
        # --- maps ---
        if name == 'keys' and len(a)==1: return list(a[0].keys())
        if name == 'values' and len(a)==1: return list(a[0].values())
        if name == 'has_key' and len(a)==2: return a[1] in a[0]
        # --- sets ---
        if name == 'to_set' and len(a)==1: return set(a[0])
        if name == 'union' and len(a)==2: return set(a[0]) | set(a[1])
        if name == 'intersection' and len(a)==2: return set(a[0]) & set(a[1])
        if name == 'difference' and len(a)==2: return set(a[0]) - set(a[1])
        # --- files, JSON, system ---
        if name == 'read_file' and len(a)==1:
            try: return Path(a[0]).read_text(encoding='utf-8')
            except OSError as e: raise ACLError(f"read_file failed: {e}", self.line)
        if name == 'write_file' and len(a)==2:
            try: Path(a[0]).write_text(str(a[1]), encoding='utf-8'); return True
            except OSError as e: raise ACLError(f"write_file failed: {e}", self.line)
        if name == 'append_file' and len(a)==2:
            try:
                with open(a[0], 'a', encoding='utf-8') as f: f.write(str(a[1]))
                return True
            except OSError as e: raise ACLError(f"append_file failed: {e}", self.line)
        if name == 'file_exists' and len(a)==1: return Path(a[0]).exists()
        if name == 'delete_file' and len(a)==1:
            try: os.remove(a[0]); return True
            except OSError as e: raise ACLError(f"delete_file failed: {e}", self.line)
        if name == 'list_files' and len(a)==1:
            try: return sorted(os.listdir(a[0]))
            except OSError as e: raise ACLError(f"list_files failed: {e}", self.line)
        if name == 'to_json' and len(a)==1:
            try: return json.dumps(a[0])
            except (TypeError, ValueError) as e: raise ACLError(f"to_json failed: {e}", self.line)
        if name == 'from_json' and len(a)==1:
            try: return json.loads(a[0])
            except (TypeError, ValueError) as e: raise ACLError(f"from_json failed: {e}", self.line)
        if name == 'arguments' and len(a)==0:
            return list(_SCRIPT_ARGS) if _SCRIPT_ARGS is not None else list(sys.argv[1:])
        if name == 'environment' and len(a)==1: return os.environ.get(a[0])
        if name == 'kind' and len(a)==1: return _kind_of(a[0])
        # --- network and security ---
        if name == 'http_get' and len(a)==1:
            try:
                req=urllib.request.Request(str(a[0]), headers={'User-Agent':'ACL/0.5'})
                with urllib.request.urlopen(req, timeout=10) as r:
                    return r.read().decode('utf-8', 'replace')
            except ACLError: raise
            except Exception as e: raise ACLError(f"http_get failed: {e}", self.line)
        if name == 'http_post' and len(a) in (2,3):
            ctype=str(a[2]) if len(a)==3 else 'application/json'
            try:
                data=str(a[1]).encode('utf-8')
                req=urllib.request.Request(str(a[0]), data=data, headers={'User-Agent':'ACL/0.5','Content-Type':ctype}, method='POST')
                with urllib.request.urlopen(req, timeout=10) as r:
                    return r.read().decode('utf-8', 'replace')
            except ACLError: raise
            except Exception as e: raise ACLError(f"http_post failed: {e}", self.line)
        if name == 'download' and len(a)==2:
            try:
                req=urllib.request.Request(str(a[0]), headers={'User-Agent':'ACL/0.5'})
                with urllib.request.urlopen(req, timeout=30) as r, open(a[1],'wb') as f:
                    f.write(r.read())
                return True
            except ACLError: raise
            except Exception as e: raise ACLError(f"download failed: {e}", self.line)
        if name == 'hash_text' and len(a)==1:
            return hashlib.sha256(str(a[0]).encode('utf-8')).hexdigest()
        if name == 'random_password' and len(a) in (1,2):
            length=max(8, min(int(a[0]), 256))
            alphabet='abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789'
            if len(a)==2 and a[1]: alphabet += '!@#$%^&*()-_=+'
            return ''.join(secrets.choice(alphabet) for _ in range(length))
        if name == 'port_open' and len(a) in (2,3):
            timeout=float(a[2]) if len(a)==3 else 2.0
            try:
                with socket.create_connection((str(a[0]), int(a[1])), timeout=timeout):
                    return True
            except OSError:
                return False
        raise ACLError(f"Unknown or invalid built-in function: {name}", self.line)

def _kind_of(v):
    if v is None: return 'nothing'
    if isinstance(v, bool): return 'truefalse'
    if isinstance(v, (int, float)): return 'number'
    if isinstance(v, str): return 'text'
    if isinstance(v, list): return 'list'
    if isinstance(v, dict): return 'map'
    if isinstance(v, set): return 'set'
    return 'unknown'

class Parser:
    def __init__(self, source):
        self.lines=[]
        for no, raw in enumerate(source.splitlines(),1):
            s=raw.strip()
            if not s or s.startswith('#') or s.startswith('//'): continue
            self.lines.append((no,s))
        self.i=0
    def parse(self, stops=()):
        out=[]
        while self.i < len(self.lines):
            no,s=self.lines[self.i]; low=s.lower()
            if low in stops or any(low.startswith(x+' ') for x in stops): break
            self.i+=1
            if low.startswith('if ') and low.endswith(' then'):
                out.append(self._parse_if(no, s[3:-5].strip())); continue
            if low.startswith('match '):
                out.append(self._parse_match(no, s[6:].strip())); continue
            if low.startswith('repeat with '):
                m=re.match(r'^repeat\s+with\s+([A-Za-z_]\w*)\s+from\s+(.+?)\s+to\s+(.+?)(?:\s+step\s+(.+?))?\s+do$', s, re.I)
                if not m: raise ACLError('Use: repeat with i from 1 to 10 do ... end repeat', no)
                body=self.parse(('end repeat','end'))
                self._end(no,('end repeat','end'))
                out.append(Stmt('for',(m.group(1), m.group(2), m.group(3), m.group(4) or ''),no,body)); continue
            if low.startswith('repeat ') and low.endswith(' times'):
                count=s[7:-6].strip(); body=self.parse(('end repeat','end'))
                self._end(no,('end repeat','end')); out.append(Stmt('repeat',(count,),no,body)); continue
            if low.startswith('while ') and low.endswith(' do'):
                cond=s[6:-3].strip(); body=self.parse(('end while','end'))
                self._end(no,('end while','end')); out.append(Stmt('while',(cond,),no,body)); continue
            if low.startswith('each '):
                m=re.match(r'^each\s+([A-Za-z_]\w*)\s+in\s+(.+?)(?:\s+do)?$', s, re.I)
                if not m: raise ACLError('Use: each item in the_list ... end each', no)
                body=self.parse(('end each','end'))
                self._end(no,('end each','end'))
                out.append(Stmt('each',(m.group(1), m.group(2)),no,body)); continue
            if low == 'try':
                body=self.parse(('catch','end try','end'))
                errname=None; other=[]
                if self.i<len(self.lines) and re.match(r'^catch(?:\s+as\s+([A-Za-z_]\w*))?$', self.lines[self.i][1], re.I):
                    errname=re.match(r'^catch(?:\s+as\s+([A-Za-z_]\w*))?$', self.lines[self.i][1], re.I).group(1) or '_error'
                    self.i+=1
                    other=self.parse(('end try','end'))
                self._end(no, ('end try','end'))
                out.append(Stmt('try',((errname or ''),),no,body,other)); continue
            if low.startswith('test '):
                m=re.match(r'^test\s+"([^"]*)"$', s, re.I)
                if not m: raise ACLError('Use: test "description" ... end test', no)
                body=self.parse(('end test','end'))
                self._end(no,('end test','end'))
                out.append(Stmt('test',(m.group(1),),no,body)); continue
            if low.startswith('check '):
                rest=s[6:].strip()
                m=re.match(r'^check\s+that\s+(.+?)\s+equals\s+(.+)$', s, re.I)
                if m: out.append(Stmt('check',(m.group(1),m.group(2)),no,[])); continue
                m=re.match(r'^check\s+that\s+(.+)$', s, re.I)
                if m: out.append(Stmt('check',(m.group(1),None),no,[])); continue
                raise ACLError('Use: check that expression  or  check that expression equals value', no)
            if low == 'exit' or low.startswith('exit with '):
                code_text = s[10:].strip() if low.startswith('exit with ') else '0'
                out.append(Stmt('exit',(code_text,),no,[])); continue
            if low.startswith('serve '):
                m=re.match(r'^serve\s+(.+?)\s+with\s+([A-Za-z_]\w*)$', s, re.I)
                if not m: raise ACLError('Use: serve 8080 with handler_function', no)
                out.append(Stmt('serve',(m.group(1),m.group(2)),no,[])); continue
            if low.startswith('to '):
                m=re.match(r'^to\s+([A-Za-z_][\w]*)\s*(?:with\s+(.+))?$',s,re.I)
                if not m: raise ACLError("Use: to function_name with parameter, another_parameter",no)
                params=[]
                for p in (x.strip() for x in (m.group(2) or '').split(',') if x.strip()):
                    pm=re.match(r'^([A-Za-z_]\w*)(?:\s+be\s+(.+))?$', p, re.S)
                    if not pm: raise ACLError(f"Bad parameter '{p}' — use: name or name be default_value", no)
                    params.append((pm.group(1), pm.group(2)))
                body=self.parse(('end function','end'))
                self._end(no,('end function','end')); out.append(Stmt('function',(m.group(1),tuple(params)),no,body)); continue
            if low in ('otherwise','end','end if','end match','end repeat','end while','end each','end try','end test','end function','catch') \
                    or low.startswith('catch ') or low.startswith('when '):
                raise ACLError(f"Unexpected '{s}'",no)
            if low.startswith('say '): out.append(Stmt('say',(s[4:].strip(),),no,[])); continue
            if low.startswith('show '): out.append(Stmt('say',(s[5:].strip(),),no,[])); continue
            if low.startswith('make '):
                m=re.match(r'^make\s+constant\s+([A-Za-z_]\w*)\s+(?:be|=)\s+(.+)$',s,re.I)
                if m: out.append(Stmt('const',(m.group(1),m.group(2)),no,[])); continue
                m=re.match(r'^make\s+([A-Za-z_]\w*)\s+as\s+(' + '|'.join(_TYPE_NAMES) + r')\s+(?:be|=)\s+(.+)$',s,re.I)
                if m: out.append(Stmt('make_typed',(m.group(1),m.group(2),m.group(3)),no,[])); continue
                m=re.match(r'^make\s+([A-Za-z_]\w*)\s+(?:be|=)\s+(.+)$',s,re.I)
                if not m: raise ACLError("Use: make variable_name be an_expression",no)
                out.append(Stmt('make',(m.group(1),m.group(2)),no,[])); continue
            if low.startswith('change '):
                m=re.match(r'^change\s+([A-Za-z_][\w]*)\s+to\s+(.+)$',s,re.I)
                if not m: raise ACLError("Use: change variable_name to an_expression",no)
                out.append(Stmt('set',(m.group(1),m.group(2)),no,[])); continue
            if low.startswith('set '):
                m=re.match(r'^set\s+(.+?)\s+to\s+(.+)$',s,re.I)
                if not m: raise ACLError('Use: set list_name[0] to value',no)
                target, value = m.group(1).strip(), m.group(2).strip()
                if re.match(r'^[A-Za-z_]\w*\[.+\]$', target):
                    out.append(Stmt('set_index',(target,value),no,[]))
                else:
                    out.append(Stmt('set',(target,value),no,[]))
                continue
            if low.startswith('put '):
                m=re.match(r'^put\s+(.+?)\s+at\s+the\s+end\s+of\s+([A-Za-z_]\w*)$',s,re.I)
                if m: out.append(Stmt('append',(m.group(1),m.group(2)),no,[])); continue
                m=re.match(r'^put\s+(.+?)\s+into\s+([A-Za-z_]\w*)$',s,re.I)
                if m: out.append(Stmt('append',(m.group(1),m.group(2)),no,[])); continue
                raise ACLError('Use: put value into list_name',no)
            if low.startswith('remove '):
                m=re.match(r'^remove\s+(?:item\s+at\s+)?(.+?)\s+from\s+([A-Za-z_]\w*)$',s,re.I)
                if m: out.append(Stmt('remove_at',(m.group(1),m.group(2)),no,[])); continue
                raise ACLError('Use: remove item at 0 from list_name',no)
            if low.startswith('clear '):
                name=s[6:].strip()
                if not re.match(r'^[A-Za-z_]\w*$', name): raise ACLError('Use: clear list_name',no)
                out.append(Stmt('clear',(name,),no,[])); continue
            if low.startswith('use '):
                m=re.match(r'^use\s+"([^"]+)"$',s,re.I)
                if not m: raise ACLError('Use: use "helpers.acl"',no)
                out.append(Stmt('use',(m.group(1),),no,[])); continue
            if low.startswith('pause '):
                out.append(Stmt('pause',(s[6:].strip(),),no,[])); continue
            if low.startswith('ask '):
                m=re.match(r'^ask\s+(.+?)\s+and\s+call\s+the\s+answer\s+(.+)$',s,re.I)
                if m: out.append(Stmt('ask',(m.group(1),m.group(2)),no,[])); continue
                m=re.match(r'^ask\s+(.+?)\s+and\s+save\s+as\s+([A-Za-z_]\w*)$',s,re.I)
                if m: out.append(Stmt('ask',(m.group(1),m.group(2)),no,[])); continue
                raise ACLError('Use: ask "Your name?" and save as name',no)
            if low.startswith('call '):
                m=re.match(r'^call\s+([A-Za-z_]\w*)(?:\s+with\s+(.+))?$',s,re.I)
                if not m: raise ACLError('Use: call function_name with value, another_value',no)
                out.append(Stmt('call',(m.group(1),m.group(2) or ''),no,[])); continue
            if low == 'give back': out.append(Stmt('return',('',),no,[])); continue
            if low.startswith('give back '): out.append(Stmt('return',(s[10:].strip(),),no,[])); continue
            if low in ('break loop','break'): out.append(Stmt('break',(),no,[])); continue
            if low in ('next loop','next'): out.append(Stmt('continue',(),no,[])); continue
            if low in ('stop','finish'): out.append(Stmt('stop',(),no,[])); continue
            if low.startswith('add '):
                m=re.match(r'^add\s+(.+?)\s+to\s+([A-Za-z_]\w*)$',s,re.I)
                if m: out.append(Stmt('set',(m.group(2),f"{m.group(2)} + ({m.group(1)})"),no,[])); continue
            raise ACLError(f"I don't recognize this instruction: {s}",no)
        return out
    def _parse_if(self, no, cond):
        body=self.parse(('otherwise','end if','end'))
        other=[]
        if self.i<len(self.lines):
            nxt=self.lines[self.i]; nxtlow=nxt[1].lower()
            if nxtlow=='otherwise':
                self.i+=1; other=self.parse(('end if','end'))
            elif nxtlow.startswith('otherwise if ') and nxtlow.endswith(' then'):
                self.i+=1
                inner=self._parse_if(nxt[0], nxt[1][len('otherwise if '):-len(' then')].strip())
                other=[inner]
        if not other or not isinstance(other[0], Stmt) or other[0].kind != 'if':
            self._end(no, ('end if','end'))
        return Stmt('if',(cond,),no,body,other)
    def _parse_match(self, no, cond):
        clauses=[]
        while self.i<len(self.lines):
            nxt=self.lines[self.i]; nxtlow=nxt[1].lower()
            if not (nxtlow.startswith('when ') and nxtlow.endswith(' then')): break
            self.i+=1
            wexpr=nxt[1][5:-5].strip()
            if not re.search(r'\bit\b', wexpr, re.I): wexpr=f"it == ({wexpr})"
            wbody=self.parse(('when','otherwise','end match','end'))
            clauses.append((wexpr,wbody))
        other=[]
        if self.i<len(self.lines) and self.lines[self.i][1].lower()=='otherwise':
            self.i+=1; other=self.parse(('end match','end'))
        self._end(no, ('end match','end'))
        return Stmt('match',(cond,tuple(clauses)),no,[],other)
    def _end(self,no,stops):
        if self.i>=len(self.lines): raise ACLError(f"Missing '{stops[0]}'",no)
        got=self.lines[self.i][1].lower()
        if got not in stops: raise ACLError(f"Expected '{stops[0]}' but found '{self.lines[self.i][1]}'",self.lines[self.i][0])
        self.i+=1

class Interpreter:
    def __init__(self, output=print, input_fn=input, max_steps=1_000_000):
        self.env={}; self.functions={}; self.output=output; self.input=input_fn
        self.max_steps=max_steps; self.steps=0
        self.var_types={}; self.constants=set()
        self.base_dir=None; self.loaded=set()
        self.test_mode=False; self.test_depth=0; self.test_results=[]
        self.exit_code=None
    def expr(self,text,line): return Expr(self.env,line,self).evaluate(text)
    def run(self,source,base_dir=None):
        self.base_dir=Path(base_dir) if base_dir else Path.cwd()
        try: self.execute(Parser(source).parse())
        except ACLReturn: pass
        except ACLBreak: raise ACLError("'break loop' can only be used inside a loop")
        except ACLContinue: raise ACLError("'next loop' can only be used inside a loop")
        except ACLExit as e: self.exit_code=e.code
        except RecursionError: raise ACLError("The program called itself too deeply")
        except ACLError: raise
        except Exception as e:
            raise ACLError(f"Internal error ({type(e).__name__}): {e}. Please report this program.")
        return self.env
    def _check_type(self, name, value, line):
        expected=self.var_types.get(name)
        if expected and _kind_of(value)!=expected:
            raise ACLError(f"'{name}' is a {expected} variable but was given a {_kind_of(value)} value",line)
    def execute(self, statements):
        for st in statements:
            self.steps+=1
            if self.steps>self.max_steps: raise ACLError('Execution limit reached (possible infinite loop)',st.line)
            k,a=st.kind,st.args
            if k=='say': self.output(self.expr(a[0],st.line))
            elif k=='make' or k=='set':
                name=a[0]
                if name in self.constants: raise ACLError(f"'{name}' is a constant and cannot be changed",st.line)
                value=self.expr(a[1],st.line)
                self._check_type(name,value,st.line)
                self.env[name]=value
            elif k=='make_typed':
                name,type_name,text=a
                value=self.expr(text,st.line)
                if _kind_of(value)!=type_name:
                    raise ACLError(f"'{name}' was declared as {type_name} but the value is a {_kind_of(value)}",st.line)
                self.var_types[name]=type_name; self.env[name]=value
            elif k=='const':
                self.env[a[0]]=self.expr(a[1],st.line); self.constants.add(a[0])
            elif k=='set_index':
                m=re.match(r'^([A-Za-z_]\w*)\[(.+)\]$', a[0], re.S)
                name, idx_text = m.group(1), m.group(2)
                if name in self.constants: raise ACLError(f"'{name}' is a constant and cannot be changed",st.line)
                if name not in self.env: raise ACLError(f"'{name}' has not been created yet",st.line)
                container=self.env[name]; idx=self.expr(idx_text,st.line); value=self.expr(a[1],st.line)
                if isinstance(container, list):
                    if not isinstance(idx,int) or not (0<=idx<len(container)):
                        raise ACLError(f"Position {idx!r} is outside the list (size {len(container)})",st.line)
                    container[idx]=value
                elif isinstance(container, dict): container[idx]=value
                else: raise ACLError("Only lists and maps can be changed by position",st.line)
            elif k=='append':
                name=a[1]
                if name in self.constants: raise ACLError(f"'{name}' is a constant and cannot be changed",st.line)
                if name not in self.env: raise ACLError(f"'{name}' has not been created yet",st.line)
                if not isinstance(self.env[name], list): raise ACLError(f"'{name}' is not a list",st.line)
                self.env[name].append(self.expr(a[0],st.line))
            elif k=='remove_at':
                name=a[1]
                if name not in self.env: raise ACLError(f"'{name}' has not been created yet",st.line)
                seq=self.env[name]
                if not isinstance(seq,list): raise ACLError(f"'{name}' is not a list",st.line)
                idx=self.expr(a[0],st.line)
                if not isinstance(idx,int) or not (0<=idx<len(seq)):
                    raise ACLError(f"Position {idx!r} is outside the list (size {len(seq)})",st.line)
                del seq[idx]
            elif k=='clear':
                if a[0] not in self.env: raise ACLError(f"'{a[0]}' has not been created yet",st.line)
                self.env[a[0]]=[] if isinstance(self.env[a[0]], list) else {}
            elif k=='ask':
                if a[1] in self.constants: raise ACLError(f"'{a[1]}' is a constant and cannot be changed",st.line)
                self.env[a[1]]=self.input(str(self.expr(a[0],st.line)))
            elif k=='if': self.execute(st.body if self.expr(a[0],st.line) else (st.other or []))
            elif k=='test':
                if not self.test_mode: continue
                self.test_depth+=1
                try:
                    self.execute(st.body)
                    self.test_results.append((st.args[0], True, '', st.line))
                except ACLError as e:
                    self.test_results.append((st.args[0], False, str(e), st.line))
                except ACLReturn: pass
                finally: self.test_depth-=1
            elif k=='check':
                if self.test_depth==0:
                    raise ACLError("'check that' can only be used inside a test block",st.line)
                actual=self.expr(a[0],st.line)
                if a[1] is None:
                    ok=bool(actual); desc=a[0]
                else:
                    expected=self.expr(a[1],st.line)
                    ok=(actual==expected); desc=f"{a[0]} equals {a[1]} (got {actual!r}, expected {expected!r})"
                if not ok: raise ACLError(f"check failed: {desc}",st.line)
            elif k=='exit':
                code=self.expr(a[0],st.line)
                if not isinstance(code,int): raise ACLError('exit needs a whole number',st.line)
                raise ACLExit(code)
            elif k=='serve': self._serve(a[0], a[1], st.line)
            elif k=='match':
                value=self.expr(a[0],st.line)
                had_it='it' in self.env; old_it=self.env.get('it')
                self.env['it']=value
                try:
                    for wexpr, wbody in a[1]:
                        if self.expr(wexpr,st.line):
                            self.execute(wbody); break
                    else:
                        self.execute(st.other or [])
                finally:
                    if had_it: self.env['it']=old_it
                    else: self.env.pop('it',None)
            elif k=='repeat':
                n=self.expr(a[0],st.line)
                if not isinstance(n,int) or n<0 or n>self.max_steps: raise ACLError('repeat needs a whole number between 0 and the execution limit',st.line)
                for _ in range(n):
                    try: self.execute(st.body)
                    except ACLContinue: continue
                    except ACLBreak: break
            elif k=='for':
                name,start_t,end_t,step_t=a
                start=self.expr(start_t,st.line); end=self.expr(end_t,st.line)
                step=self.expr(step_t,st.line) if step_t else 1
                for v in (start,end,step):
                    if not isinstance(v,int): raise ACLError('repeat with ... from/to/step needs whole numbers',st.line)
                if step==0: raise ACLError('step cannot be zero',st.line)
                i=start
                while (step>0 and i<=end) or (step<0 and i>=end):
                    self.steps+=1
                    if self.steps>self.max_steps: raise ACLError('Execution limit reached (possible infinite loop)',st.line)
                    self.env[name]=i
                    try: self.execute(st.body)
                    except ACLContinue: pass
                    except ACLBreak: break
                    i+=step
            elif k=='each':
                name, expr_t=a
                seq=self.expr(expr_t,st.line)
                if isinstance(seq,set): items=sorted(seq, key=repr)
                elif isinstance(seq,dict): items=list(seq.keys())
                elif isinstance(seq,(list,tuple,str)): items=list(seq)
                else: raise ACLError('each needs a list, map, set, or text value',st.line)
                for item in items:
                    self.steps+=1
                    if self.steps>self.max_steps: raise ACLError('Execution limit reached (possible infinite loop)',st.line)
                    self.env[name]=item
                    try: self.execute(st.body)
                    except ACLContinue: continue
                    except ACLBreak: break
            elif k=='while':
                while self.expr(a[0],st.line):
                    self.steps+=1
                    if self.steps>self.max_steps: raise ACLError('Execution limit reached (possible infinite loop)',st.line)
                    try: self.execute(st.body)
                    except ACLContinue: continue
                    except ACLBreak: break
            elif k=='try':
                try: self.execute(st.body)
                except (ACLReturn, ACLBreak, ACLContinue): raise
                except ACLError as e:
                    if st.other:
                        if st.args and st.args[0]: self.env[st.args[0]]=str(e)
                        self.execute(st.other)
            elif k=='use': self._use(a[0],st.line)
            elif k=='pause':
                secs=self.expr(a[0],st.line)
                if not isinstance(secs,(int,float)) or secs<0: raise ACLError('pause needs a number of seconds (0 or more)',st.line)
                time.sleep(min(secs,60))
            elif k=='function': self.functions[a[0]]=(a[1],st.body,st.line)
            elif k=='call':
                name, raw=a
                if name in self.functions:
                    vals=[] if not raw.strip() else [self.expr(v,st.line) for v in self._split_args(raw,st.line)]
                    result=self.call_function(name,vals,st.line)
                else:
                    try: result=self.expr(f"{name}({raw})",st.line)
                    except ACLError as e:
                        if 'Unknown or invalid built-in' in str(e) or 'Unknown function' in str(e):
                            raise ACLError(f"Function '{name}' does not exist",st.line) from e
                        raise
                self.env['_last_result']=result
            elif k=='return':
                raise ACLReturn(self.expr(a[0],st.line) if a[0] else None)
            elif k=='break': raise ACLBreak()
            elif k=='continue': raise ACLContinue()
            elif k=='stop': raise ACLReturn(None)
    def call_function(self, name, vals, line):
        if name not in self.functions: raise ACLError(f"Function '{name}' does not exist",line)
        params,body,defline=self.functions[name]
        required=sum(1 for _,d in params if d is None)
        if len(vals)<required or len(vals)>len(params):
            raise ACLError(f"Function '{name}' expects between {required} and {len(params)} argument(s), got {len(vals)}",line)
        old=self.env; self.env=dict(old)
        try:
            for (p,_),v in zip(params,vals): self.env[p]=v
            for p,d in params[len(vals):]:
                self.env[p]=self.expr(d,defline)
            try:
                self.execute(body); result=None
            except ACLReturn as r: result=r.value
            except RecursionError:
                raise ACLError(f"Function '{name}' called itself too deeply",defline)
            return result
        finally: self.env=old
    def _use(self, fname, line):
        path=Path(fname)
        if not path.is_absolute(): path=self.base_dir/path
        path=path.resolve()
        if path in self.loaded: return
        if not path.is_file(): raise ACLError(f"Cannot find module file: {path}",line)
        try: source=path.read_text(encoding='utf-8')
        except OSError as e: raise ACLError(f"Cannot read module {path}: {e}",line)
        self.loaded.add(path)
        old_base=self.base_dir; self.base_dir=path.parent
        try:
            try: self.execute(Parser(source).parse())
            except RecursionError: raise ACLError("Modules import each other too deeply",line)
        finally: self.base_dir=old_base
    def _serve(self, port_text, fname, line):
        """Run a real HTTP server; each request calls an ACL function with a
        request map {method, path, body}. The handler returns the response
        text, or a map with status/body/content_type."""
        if fname not in self.functions: raise ACLError(f"Function '{fname}' does not exist", line)
        port=self.expr(port_text, line)
        if not isinstance(port,int) or not (0 < port < 65536): raise ACLError('serve needs a whole-number port between 1 and 65535', line)
        interp=self
        class Handler(http.server.BaseHTTPRequestHandler):
            def _handle(self):
                try: length=int(self.headers.get('Content-Length') or 0)
                except ValueError: length=0
                body=self.rfile.read(length).decode('utf-8','replace') if length else ''
                req={'method': self.command, 'path': self.path, 'body': body}
                try: result=interp.call_function(fname,[req],line)
                except ACLError as e: result={'status':500,'body':'ACL error: '+str(e),'content_type':'text/plain; charset=utf-8'}
                if isinstance(result,dict) and 'body' in result:
                    status=int(result.get('status',200)); text=str(result.get('body',''))
                    ctype=str(result.get('content_type','text/plain; charset=utf-8'))
                else:
                    status=200; text='' if result is None else str(result); ctype='text/plain; charset=utf-8'
                data=text.encode('utf-8')
                self.send_response(status)
                self.send_header('Content-Type',ctype)
                self.send_header('Content-Length',str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            do_GET=_handle
            do_POST=_handle
            def log_message(self, *args): pass
        try: server=http.server.HTTPServer(('127.0.0.1', port), Handler)
        except OSError as e: raise ACLError(f"Cannot start server on port {port}: {e}", line)
        self.output(f"Serving on http://127.0.0.1:{port} — press Ctrl+C to stop")
        try: server.serve_forever()
        except KeyboardInterrupt: pass
        finally: server.server_close()
    def _split_args(self,raw,line):
        # Comma splitter that respects strings and brackets.
        parts=[]; start=0; depth=0; quote=None; esc=False
        for i,c in enumerate(raw):
            if quote:
                if esc: esc=False
                elif c=='\\': esc=True
                elif c==quote: quote=None
            elif c in ('"',"'"): quote=c
            elif c in '([': depth+=1
            elif c in ')]': depth-=1
            elif c==',' and depth==0: parts.append(raw[start:i].strip()); start=i+1
        parts.append(raw[start:].strip())
        if any(not x for x in parts): raise ACLError('Empty function argument',line)
        return parts

def run_file(path):
    p=Path(path)
    try: source=p.read_text(encoding='utf-8')
    except OSError as e: print(f"ACL: cannot read {p}: {e}",file=sys.stderr); return 2
    vm=Interpreter()
    try: vm.run(source, base_dir=p.parent)
    except ACLExit as e: return e.code
    except ACLError as e: print(f"ACL error: {e}",file=sys.stderr); return 1
    except Exception as e: print(f"ACL internal error: {type(e).__name__}: {e}",file=sys.stderr); return 1
    except KeyboardInterrupt: print('\nACL: interrupted',file=sys.stderr); return 130
    if vm.exit_code is not None: return vm.exit_code
    return 0
