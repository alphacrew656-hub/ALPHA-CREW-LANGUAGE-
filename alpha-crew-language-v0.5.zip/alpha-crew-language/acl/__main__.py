import argparse
from pathlib import Path
from .runtime import VERSION, run_file, Interpreter, ACLError, set_script_args

_BLOCK_OPEN = ('if ','repeat','while ','to ','try','each ','match ')

def _repl():
    print(f'Alpha Crew Language {VERSION} — type :quit to leave')
    vm=Interpreter()
    buffer=[]; depth=0
    while True:
        prompt='...   ' if depth>0 else 'acl> '
        try: line=input(prompt)
        except (EOFError,KeyboardInterrupt): print(); break
        text=line.strip()
        if depth==0 and text==':quit': break
        if depth==0 and not text: continue
        low=text.lower()
        if not (depth>0 and (low.startswith('otherwise') or low.startswith('when ') or low.startswith('catch'))):
            if low.startswith(_BLOCK_OPEN) or low=='try': depth+=1
            if low.startswith('end '): depth-=1
        buffer.append(line)
        if depth>0: continue
        source='\n'.join(buffer); buffer=[]; depth=0
        try: vm.run(source, base_dir=Path.cwd())
        except ACLError as e: print(f'ACL error: {e}')

def _run_tests(rest):
    """Run ACL test files and report pass/fail per test block."""
    from .runtime import ACLError
    from . import tools  # noqa: F401
    targets = rest or ['tests']
    files=[]
    for t in targets:
        tp=Path(t)
        if tp.is_dir(): files.extend(sorted(tp.glob('*.acl')))
        else: files.append(tp)
    if not files:
        print('No test files found'); return 1
    failures=0; total=0
    for f in files:
        try: source=f.read_text(encoding='utf-8')
        except OSError as e: print(f'[ERROR] {f}: {e}'); failures+=1; continue
        vm=Interpreter(output=lambda s: None)
        vm.test_mode=True
        try: vm.run(source, base_dir=f.parent)
        except ACLError as e: print(f'[ERROR] {f}: {e}'); failures+=1; continue
        for name, ok, msg, line in vm.test_results:
            total+=1
            status='PASS' if ok else 'FAIL'
            print(f'[{status}] {f}: {name}' + (f' — {msg}' if msg else ''))
            if not ok: failures+=1
    print(f'{total} test(s), {failures} failure(s)')
    return 1 if failures else 0

def _cmd_check(target):
    from .runtime import Parser
    try: Parser(Path(target).read_text(encoding='utf-8')).parse()
    except (OSError,ACLError) as e: print(f'ACL error: {e}'); return 1
    print(f'{target}: syntax looks good'); return 0

def main(argv=None):
    # Manual dispatch for subcommands so `acl file.acl` keeps working.
    args=list(argv if argv is not None else __import__('sys').argv[1:])
    if args and args[0] in ('new','format','lint','run','test','check','package'):
        cmd, rest = args[0], args[1:]
        if not rest and cmd not in ('test',):
            print(f'Usage: acl {cmd} <file_or_project>'); return 2
        if cmd=='new': return __import__('acl.tools', fromlist=['tools']).new_project(rest[0])
        if cmd=='format': return __import__('acl.tools', fromlist=['tools'])._format_file(rest[-1], write='-w' in rest)
        if cmd=='lint': return __import__('acl.tools', fromlist=['tools']).lint_file(rest[0])
        if cmd=='package': return __import__('acl.tools', fromlist=['tools']).package_project(rest[0])
        if cmd=='run': set_script_args(rest[1:]); return run_file(rest[0])
        if cmd=='check': return _cmd_check(rest[0])
        if cmd=='test': return _run_tests(rest)
    p=argparse.ArgumentParser(prog='acl', description='Alpha Crew Language — readable programming for everyone')
    p.add_argument('file', nargs='?', help='a .acl source file')
    p.add_argument('--version', action='version', version=f'Alpha Crew Language {VERSION}')
    p.add_argument('--check', action='store_true', help='parse the source without running it')
    p.add_argument('--repl', action='store_true', help='start the interactive shell')
    a, rest = p.parse_known_args(args)
    if not a.repl: set_script_args(rest)
    if a.repl:
        _repl(); return 0
    if not a.file:
        _repl(); return 0
    if a.check:
        return _cmd_check(a.file)
    return run_file(a.file)
if __name__=='__main__': raise SystemExit(main())
