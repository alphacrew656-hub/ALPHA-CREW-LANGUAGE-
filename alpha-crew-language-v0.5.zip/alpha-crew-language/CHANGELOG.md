# Changelog

## 0.5.0 — Networking and security

- Real HTTP web server in ACL: `serve port with handler` (handlers receive a
  `{method, path, body}` map and return text or a `{status, body, content_type}`
  response; runs on 127.0.0.1).
- HTTP client built-ins: `http_get`, `http_post`, `download`, with certificate
  verification on by default.
- Security utilities for defensive work: `hash_text` (SHA-256),
  `random_password` (cryptographically secure), `port_open` (connectivity check).
- `acl package` bundles a project into a distributable `.aclpack` archive.
- New examples: `api_server.acl` (working JSON API) and `guess.acl` (game).
- 65 automated tests, including a live server roundtrip test.

## 0.4.0 — Stable core

- Built-in test framework: `test "name" ... check that ... end test`, plus the
  `acl test` runner with pass/fail output and exit codes.
- Short-circuit `and` / `or` (safe guards like `i < length(list) and list[i]` now work).
- `exit` and `exit with N` statements for command-line applications.
- Stability hardening: a safety net converts every internal fault into a friendly
  ACL error (no tracebacks), 400-case fuzz testing, hardened `random`/`min`/`max`,
  `TypeError`-safe indexing.
- `acl format -w` writes the formatted file in place.
- 60 automated tests.

## 0.3.0 — Core language expansion

- Typed variables (`make score as number be 0`) and constants (`make constant MAX be 10`).
- Sets (`{1, 2, 3}`) with `union`, `intersection`, `difference`.
- Pattern matching: `match ... when ... then ... otherwise ... end match` with `it`.
- Default parameters (`to greet with name, greeting be "Hello"`).
- Standard library: file I/O, JSON, command-line arguments, environment variables,
  `format()` text interpolation.
- Developer tools: `acl new`, `acl lint`, `acl format`, `acl check`, `acl run`.
- Performance: cached expression parsing; memory guards on repetition and powers.

## 0.2.0 — Standalone prototype

- `each` loops, `repeat with i from ... to ...` loops, `break loop` / `next loop`,
  `otherwise if` chains, `try ... catch as err`, maps, list operations,
  function return values in expressions, recursion, modules (`use`), multi-line REPL.

## 0.1.0 — Language concept

- First working interpreter: variables, arithmetic, conditions, loops, output,
  input, functions, safe expression engine.
